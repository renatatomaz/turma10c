package br.com.itaumon.beans;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "TB_EQUIPAMENTO")
public class Equipamento {
	
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	@Id
	@Column(name = "id_equip")
	private int id;
	
	@Column(name = "hostName", length = 50)
	private String hostName;
	
	@Column(name = "ip", length = 15)
	private String ip;
	
	@JsonIgnoreProperties("equip")
	@OneToMany(mappedBy = "equip", cascade = CascadeType.ALL)
	// cascade = Pergunta o que fazer se você alterar ou excluir o artista? Ele irá refletir o mesmo que for feito em musica.
	private List<Evento> equipeventos;
	
	public List<Evento> getEvento () {
		return equipeventos;
	}

	public void setEvento (List<Evento> equipeventos) {
		this.equipeventos = equipeventos;
	}
		
	public Equipamento() {
		super();
	}
	
	public Equipamento(int id, String hostName, String ip) {
		super();
		this.id = id;
		this.hostName = hostName;
		this.ip = ip;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	
}
