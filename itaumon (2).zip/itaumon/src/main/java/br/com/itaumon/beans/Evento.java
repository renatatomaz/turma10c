package br.com.itaumon.beans;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="TB_EVENTO")

public class Evento {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column (name = "num_seq")
	private int numSeq;
	
	@Column (name = "data_evt")
	@Temporal(TemporalType.DATE)
	private Date data;
	
	@JsonIgnoreProperties("alarmeventos")
	@ManyToOne
	private Alarme alarme;
	
	@JsonIgnoreProperties("equipeventos")
	@ManyToOne
	private Equipamento equip;
	
	
	public Evento() {
		super();
	}

	public Evento(int numSeq, Date data, Alarme alarme, Equipamento equip) {
		super();
		this.numSeq = numSeq;
		this.data = data;
		this.alarme = alarme;
		this.equip = equip;
	}

	public int getNumSeq() {
		return numSeq;
	}

	public void setNumSeq(int numSeq) {
		this.numSeq = numSeq;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public Alarme getAlarme() {
		return alarme;
	}

	public void setAlarme(Alarme alarme) {
		this.alarme = alarme;
	}

	public Equipamento getEquip() {
		return equip;
	}

	public void setEquip(Equipamento equip) {
		this.equip = equip;
	}
	
}
