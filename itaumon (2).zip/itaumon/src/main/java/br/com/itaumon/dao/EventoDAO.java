package br.com.itaumon.dao;

import org.springframework.data.repository.CrudRepository;

import br.com.itaumon.beans.Evento;

public interface EventoDAO extends CrudRepository <Evento, Integer>{

}
